using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class BattleUIManager : MonoBehaviour
{
    public List<Image> characterProfileIcons; // Assign 3 Image UI components in Inspector

    void Start()
    {
        List<CharacterData> team = TeamManager.Instance.selectedTeam;

        for (int i = 0; i < team.Count; i++)
        {
            CharacterData data = team[i];

            if (data != null)
            {
                characterProfileIcons[i].sprite = data.profileIcon;
            }
        }
    }
}
