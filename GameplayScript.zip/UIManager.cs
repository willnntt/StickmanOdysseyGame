using UnityEngine;
using TMPro;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    [SerializeField] private GameObject winScreen;
    [SerializeField] private GameObject loseScreen;
    [SerializeField] private GameObject actionMenuPanel;
    [SerializeField] private RectTransform turnOrderLabel;

    private Vector3 actionMenuOriginalPosition;
    private Vector3 labelOriginalPosition;
    private Vector3 offScreenOffset = new Vector3(0, -300, 0); // Adjust as needed

    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);

        actionMenuOriginalPosition = actionMenuPanel.GetComponent<RectTransform>().anchoredPosition;
        labelOriginalPosition = turnOrderLabel.anchoredPosition;
    }

    public void ShowWinScreen()
    {
        winScreen.SetActive(true);
        TurnManager.Instance.enabled = false;
    }

    public void ShowLoseScreen()
    {
        loseScreen.SetActive(true);
        TurnManager.Instance.enabled = false;
    }

    public void ShowActionMenu()
    {
        actionMenuPanel.GetComponent<RectTransform>().anchoredPosition = actionMenuOriginalPosition;
        turnOrderLabel.anchoredPosition = labelOriginalPosition;
    }

    public void HideActionMenu()
    {
        actionMenuPanel.GetComponent<RectTransform>().anchoredPosition = actionMenuOriginalPosition + offScreenOffset;
        turnOrderLabel.anchoredPosition = labelOriginalPosition + offScreenOffset;
    }
}
