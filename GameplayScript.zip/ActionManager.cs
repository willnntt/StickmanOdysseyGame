using System.Collections;
using UnityEngine;

public class ActionManager : MonoBehaviour
{
    public static ActionManager Instance;

    private PlayerController currentPlayer;

    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    private IEnumerator WaitForPlayerAction(PlayerController player)
    {
        while (!player.HasFinishedAction())
            yield return null;

        yield return new WaitForSeconds(0.5f);
        TurnManager.Instance.StartTurn();
    }

    public void StartPlayerTurn(PlayerController player)
    {
        Debug.Log("Player " + player.name + "'s turn started.");
        currentPlayer = player;
        currentPlayer.StartTurn();
    }

    public void StartEnemyTurn(EnemyController enemy)
    {
        Debug.Log("Enemy " + enemy.name + "'s turn started.");
        enemy.StartTurn();
        StartCoroutine(WaitForEnemyAction(enemy));
    }

    private IEnumerator WaitForEnemyAction(EnemyController enemy)
    {
        while (!enemy.HasFinishedAction())
            yield return null;

        yield return new WaitForSeconds(0.5f);
        TurnManager.Instance.StartTurn();
    }

    // === UI Button Callbacks ===
    public void OnMoveButtonPressed()
    {
        if (currentPlayer != null)
        {
            Debug.Log("Move button pressed.");
            currentPlayer.EnableMovementMode();
        }
        else
        {
            Debug.LogWarning("Move button pressed but currentPlayer is null!");
        }
    }

    public void OnAttackButtonPressed()
    {
        if (currentPlayer != null)
        {
            Debug.Log("Attack button pressed.");
            currentPlayer.EnableAttackMode();
        }
        else
        {
            Debug.LogWarning("Attack button pressed but currentPlayer is null!");
        }
    }
}
