using System.Collections;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public EnemyData enemyData;

    private int currentHP;
    private bool hasFinishedAction = false;
    private Transform targetPlayer;

    public int MaxHP => enemyData.maxHP;
    public int CurrentHP
    {
        get => currentHP;
        set
        {
            currentHP = Mathf.Max(0, value);
            HealthManager.Instance?.UpdateEnemyHealth(this);
        }
    }
    public int AttackDamage => enemyData.attackDamage;
    public float AttackRange => enemyData.attackRange;
    public int Defense => enemyData.defense;
    public float MovementSpeed => enemyData.movementSpeed;
    public float MovementRange => enemyData.movementRange;
    public float ActionSpeed => enemyData.actionSpeed;

    private void Start()
    {
        currentHP = MaxHP;
        HealthManager.Instance?.UpdateEnemyHealth(this);
    }

    private void Update()
    {
        if (CurrentHP <= 0)
        {
            Die();
        }
    }

    public void StartTurn()
    {
        hasFinishedAction = false;

        targetPlayer = FindClosestPlayer();
        if (targetPlayer == null)
        {
            Debug.Log("No valid player target.");
            hasFinishedAction = true;
            return;
        }

        float distanceToPlayer = Vector3.Distance(transform.position, targetPlayer.position);

        if (distanceToPlayer <= AttackRange)
        {
            PerformAttack(targetPlayer.GetComponent<PlayerController>());
        }
        else
        {
            MoveTowardsPlayer(targetPlayer.position);
        }
    }

    public void EndTurn()
    {
        Debug.Log("Enemy's turn ended.");
    }

    public void PerformAttack(PlayerController player)
    {
        if (player != null)
        {
            player.TakeDamage(AttackDamage);
            Debug.Log("Enemy attacked the player.");
        }

        hasFinishedAction = true;
    }

    public void MoveTowardsPlayer(Vector3 playerPosition)
    {
        StartCoroutine(MoveToTarget(playerPosition));
    }

    private IEnumerator MoveToTarget(Vector3 targetPosition)
    {
        float step = MovementSpeed * Time.deltaTime;
        while (Vector3.Distance(transform.position, targetPosition) > 0.1f)
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPosition, step);
            yield return null;
        }
        hasFinishedAction = true;
        Debug.Log("Enemy has moved to the target.");
    }

    private Transform FindClosestPlayer()
    {
        PlayerController[] players = FindObjectsOfType<PlayerController>();
        Transform closestPlayer = null;
        float closestDistance = Mathf.Infinity;

        foreach (var player in players)
        {
            if (player.CurrentHP > 0)
            {
                float distance = Vector3.Distance(transform.position, player.transform.position);
                if (distance < closestDistance)
                {
                    closestDistance = distance;
                    closestPlayer = player.transform;
                }
            }
        }

        return closestPlayer;
    }

    public void TakeDamage(int damage)
    {
        int damageTaken = Mathf.Max(0, damage - Defense);
        CurrentHP -= damageTaken;
    }

    private void Die()
    {
        gameObject.SetActive(false);
        hasFinishedAction = true;
        Debug.Log("Enemy has died.");
    }

    public bool HasFinishedAction()
    {
        return hasFinishedAction;
    }
}
