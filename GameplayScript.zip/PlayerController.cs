using System.Collections;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public CharacterData characterData;

    private int currentHP;

    private bool canMove = false;
    private bool canAttack = false;
    private bool hasFinishedAction = false;

    public int MaxHP => characterData.maxHP;
    public int CurrentHP
    {
        get => currentHP;
        set
        {
            currentHP = Mathf.Max(0, value);
            HealthManager.Instance?.UpdatePlayerHealth(this);
        }
    }
    public int AttackDamage => characterData.attackDamage;
    public float AttackRange => characterData.attackRange;
    public int Defense => characterData.defense;
    public float MovementSpeed => characterData.movementSpeed;
    public float MovementRange => characterData.movementRange;
    public float ActionSpeed => characterData.actionSpeed;

    private void Start()
    {
        currentHP = MaxHP;
        HealthManager.Instance?.UpdatePlayerHealth(this);
    }

    private void Update()
    {
        if (CurrentHP <= 0)
        {
            Die();
        }
    }

    public void StartTurn()
    {
        hasFinishedAction = false;
        canMove = false;
        canAttack = false;
        Debug.Log("Player's turn started.");
    }

    public void EndTurn()
    {
        hasFinishedAction = true;
        canMove = false;
        canAttack = false;
        Debug.Log("Player's turn ended.");
    }

    public void EnableMovementMode()
    {
        canMove = true;
        canAttack = false;
    }

    public void EnableAttackMode()
    {
        canAttack = true;
        canMove = false;
    }

    public void Move(Vector3 targetPosition)
    {
        if (!canMove || hasFinishedAction) return;
        StartCoroutine(MoveToTarget(targetPosition));
    }

    private IEnumerator MoveToTarget(Vector3 targetPosition)
    {
        float step = MovementSpeed * Time.deltaTime;
        while (Vector3.Distance(transform.position, targetPosition) > 0.1f)
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPosition, step);
            yield return null;
        }

        canMove = false;
        hasFinishedAction = true;
        Debug.Log("Player has moved to the target.");
    }

    public void Attack(EnemyController enemy)
    {
        if (!canAttack || hasFinishedAction) return;

        if (Vector3.Distance(transform.position, enemy.transform.position) <= AttackRange)
        {
            enemy.TakeDamage(AttackDamage);
            canAttack = false;
            hasFinishedAction = true;
            Debug.Log("Player attacked the enemy.");
        }
    }

    public void TakeDamage(int damage)
    {
        int damageTaken = Mathf.Max(0, damage - Defense);
        CurrentHP -= damageTaken;
    }

    public void Die()
    {
        gameObject.SetActive(false);
        Debug.Log("Player has died.");
    }

    public bool HasFinishedAction()
    {
        return hasFinishedAction;
    }
}
