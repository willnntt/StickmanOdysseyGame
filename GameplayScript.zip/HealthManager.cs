using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthManager : MonoBehaviour
{
    public static HealthManager Instance;

    public Image[] playerHealthBars; // assign in Inspector
    public Image[] enemyHealthBars;  // assign in Inspector

    private Dictionary<PlayerController, Image> playerHealthMap = new();
    private Dictionary<EnemyController, Image> enemyHealthMap = new();

    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    public void RegisterPlayers(List<PlayerController> players)
    {
        for (int i = 0; i < players.Count && i < playerHealthBars.Length; i++)
        {
            playerHealthMap[players[i]] = playerHealthBars[i];
            UpdatePlayerHealth(players[i]); // initialize
        }
    }

    public void RegisterEnemies(List<EnemyController> enemies)
    {
        for (int i = 0; i < enemies.Count && i < enemyHealthBars.Length; i++)
        {
            enemyHealthMap[enemies[i]] = enemyHealthBars[i];
            UpdateEnemyHealth(enemies[i]); // initialize
        }
    }

    public void UpdatePlayerHealth(PlayerController player)
    {
        if (playerHealthMap.TryGetValue(player, out Image bar))
        {
            bar.fillAmount = (float)player.CurrentHP / player.MaxHP;
        }
    }

    public void UpdateEnemyHealth(EnemyController enemy)
    {
        if (enemyHealthMap.TryGetValue(enemy, out Image bar))
        {
            bar.fillAmount = (float)enemy.CurrentHP / enemy.MaxHP;
        }
    }
}
