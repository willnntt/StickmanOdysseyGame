using UnityEngine;

[CreateAssetMenu(fileName = "CharacterData", menuName = "Game/CharacterData")]
public class CharacterData : ScriptableObject
{
    public int characterId; // ✅ Use this ID to link prefab/selection
    public string characterName;
    public Sprite profileIcon;
    public Sprite sprite;

    [Header("Health Settings")]
    public int maxHP = 100;

    [Header("Combat Stats")]
    public int attackDamage = 10;
    public float attackRange = 2f;
    public int defense = 5;

    [Header("Movement Settings")]
    public float movementSpeed = 5f;
    public float movementRange = 3f;
    public float actionSpeed = 12f;
}
