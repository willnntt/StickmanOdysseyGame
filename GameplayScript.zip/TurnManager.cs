using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class TurnManager : MonoBehaviour
{
    public static TurnManager Instance;

    public List<PlayerController> players = new List<PlayerController>();
    public List<EnemyController> enemies = new List<EnemyController>();

    public List<Transform> playerSpawnPoints = new List<Transform>();
    public List<Transform> enemySpawnPoints = new List<Transform>();

    public GameObject playerPrefab;
    public GameObject enemyPrefab;

    private List<TurnActor> turnQueue = new List<TurnActor>();
    private int currentTurnIndex = 0;
    private bool isGameOver = false;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Debug.LogWarning("Duplicate TurnManager detected. Destroying this one.");
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private IEnumerator Start()
    {
        // Wait until TeamManager and EnemyManager are ready
        yield return new WaitUntil(() => 
            TeamManager.Instance != null && 
            EnemyManager.Instance != null &&
            TeamManager.Instance.selectedTeam.Count > 0 &&
            EnemyManager.Instance.selectedEnemies.Count > 0
        );

        // Spawn characters
        SpawnPlayers();
        SpawnEnemies();

        // Wait a frame to ensure they're added to the lists
        yield return null;

        // Register with HealthManager
        HealthManager.Instance.RegisterPlayers(players);
        HealthManager.Instance.RegisterEnemies(enemies);

        // Build turn queue after everything is ready
        BuildTurnQueue();
        StartTurn();
    }

    private void SpawnPlayers()
    {
        int spawnIndex = 0;

        foreach (CharacterData data in TeamManager.Instance.selectedTeam)
        {
            GameObject obj = Instantiate(playerPrefab, playerSpawnPoints[spawnIndex % playerSpawnPoints.Count].position, Quaternion.identity);
            PlayerController controller = obj.GetComponent<PlayerController>();
            controller.characterData = data;

            SpriteRenderer sr = obj.GetComponent<SpriteRenderer>();
            if (sr != null && data.sprite != null)
                sr.sprite = data.sprite;

            players.Add(controller);
            spawnIndex++;
        }
    }

    private void SpawnEnemies()
    {
        int spawnIndex = 0;

        foreach (EnemyData data in EnemyManager.Instance.selectedEnemies)
        {
            GameObject obj = Instantiate(enemyPrefab, enemySpawnPoints[spawnIndex % enemySpawnPoints.Count].position, Quaternion.identity);
            EnemyController controller = obj.GetComponent<EnemyController>();
            controller.enemyData = data;

            SpriteRenderer sr = obj.GetComponent<SpriteRenderer>();
            if (sr != null && data.sprite != null)
                sr.sprite = data.sprite;

            enemies.Add(controller);
            spawnIndex++;
        }
    }

    private void BuildTurnQueue()
    {
        turnQueue.Clear();

        Debug.Log($"Building Turn Queue: {players.Count} players, {enemies.Count} enemies.");

        foreach (var player in players)
        {
            if (player.CurrentHP > 0)
                turnQueue.Add(new TurnActor(player.characterData.actionSpeed, player));
        }

        foreach (var enemy in enemies)
        {
            if (enemy.CurrentHP > 0)
                turnQueue.Add(new TurnActor(enemy.enemyData.actionSpeed, enemy));
        }

        if (turnQueue.Count == 0)
        {
            Debug.LogWarning("Turn queue is empty! No valid actors.");
        }

        turnQueue = turnQueue.OrderByDescending(a => a.actionSpeed).ToList();
        currentTurnIndex = 0;
    }

    public void StartTurn()
    {
        if (isGameOver || turnQueue.Count == 0)
        {
            Debug.LogWarning("Turn skipped. Game over or turn queue empty.");
            return;
        }

        if (currentTurnIndex >= turnQueue.Count)
        {
            BuildTurnQueue();
            currentTurnIndex = 0;
        }

        TurnActor actor = turnQueue[currentTurnIndex];

        if (actor.player != null)
        {
            Debug.Log($"Player {actor.player.name}'s turn started.");
            ActionManager.Instance?.StartPlayerTurn(actor.player);
        }
        else if (actor.enemy != null)
        {
            Debug.Log($"Enemy {actor.enemy.name}'s turn started.");
            ActionManager.Instance?.StartEnemyTurn(actor.enemy);
        }
    }

    public void EndTurn()
    {
        if (isGameOver) return;

        currentTurnIndex++;
        CheckGameOver();

        if (!isGameOver)
        {
            StartTurn();
        }
    }

    private void CheckGameOver()
    {
        bool allPlayersDead = players.All(p => p.CurrentHP <= 0);
        bool allEnemiesDead = enemies.All(e => e.CurrentHP <= 0);

        if (allPlayersDead)
        {
            isGameOver = true;
            Debug.Log("The enemies win! Game Over.");
            StopAllActions();
        }
        else if (allEnemiesDead)
        {
            isGameOver = true;
            Debug.Log("The players win! Game Over.");
            StopAllActions();
        }
    }

    private void StopAllActions()
    {
        foreach (var p in players)
            p.enabled = false;

        foreach (var e in enemies)
            e.enabled = false;
    }

    private class TurnActor
    {
        public float actionSpeed;
        public PlayerController player;
        public EnemyController enemy;

        public TurnActor(float speed, PlayerController p)
        {
            actionSpeed = speed;
            player = p;
        }

        public TurnActor(float speed, EnemyController e)
        {
            actionSpeed = speed;
            enemy = e;
        }
    }
}
